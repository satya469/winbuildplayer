self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "28f70a0ce4934e497712e1d39c39d4f7",
    "url": "/index.html"
  },
  {
    "revision": "7a113b284e93e416c17e",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "3d1cf865cfd25df52df0",
    "url": "/static/css/12.2e947bf2.chunk.css"
  },
  {
    "revision": "91c6b1414ebc377482d1",
    "url": "/static/css/13.61daa1a6.chunk.css"
  },
  {
    "revision": "7726082fc7f36f1bf476",
    "url": "/static/css/14.834d426e.chunk.css"
  },
  {
    "revision": "5905b3d2ea32786aed4e",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "7a113b284e93e416c17e",
    "url": "/static/js/0.766b1d53.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.766b1d53.chunk.js.LICENSE.txt"
  },
  {
    "revision": "2c5dde535986e8031ea7",
    "url": "/static/js/1.d8ee5c5d.chunk.js"
  },
  {
    "revision": "3d1cf865cfd25df52df0",
    "url": "/static/js/12.b93cd5f2.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/12.b93cd5f2.chunk.js.LICENSE.txt"
  },
  {
    "revision": "91c6b1414ebc377482d1",
    "url": "/static/js/13.f03840df.chunk.js"
  },
  {
    "revision": "7726082fc7f36f1bf476",
    "url": "/static/js/14.70a0845c.chunk.js"
  },
  {
    "revision": "0421358a87686ed9d93c",
    "url": "/static/js/15.08b4ed74.chunk.js"
  },
  {
    "revision": "0b1ea6968ba45f98b202",
    "url": "/static/js/16.a7a08c74.chunk.js"
  },
  {
    "revision": "b63e165693ed47b8b84c",
    "url": "/static/js/17.d181e156.chunk.js"
  },
  {
    "revision": "f4d3812e17ec79802d4e",
    "url": "/static/js/18.0aae21c1.chunk.js"
  },
  {
    "revision": "0123455b7bc2ca089ee1",
    "url": "/static/js/19.b76ec354.chunk.js"
  },
  {
    "revision": "dc225a654e4d6442fa63",
    "url": "/static/js/2.636a88b5.chunk.js"
  },
  {
    "revision": "fa5f1e0d7ec0760bec1d",
    "url": "/static/js/20.3b893afe.chunk.js"
  },
  {
    "revision": "1fbaaa8663ca6af16378",
    "url": "/static/js/21.9af93b6b.chunk.js"
  },
  {
    "revision": "6566301f72a341c708f7",
    "url": "/static/js/22.a9ca988c.chunk.js"
  },
  {
    "revision": "b630cd8b74ae4d5388de",
    "url": "/static/js/23.6afa78b6.chunk.js"
  },
  {
    "revision": "791a319c02bb1804c1b9",
    "url": "/static/js/24.a56cc57c.chunk.js"
  },
  {
    "revision": "8f78b9d6838172fda5d4",
    "url": "/static/js/25.511bd80f.chunk.js"
  },
  {
    "revision": "18cf1e70f09ffb93cf1b",
    "url": "/static/js/26.95120941.chunk.js"
  },
  {
    "revision": "4815c3d61d394f872000",
    "url": "/static/js/27.ace3f871.chunk.js"
  },
  {
    "revision": "efbd5f4f36500c8187db",
    "url": "/static/js/28.e9ba1ddb.chunk.js"
  },
  {
    "revision": "8b78360a04f0bda9676c",
    "url": "/static/js/29.6c0366a3.chunk.js"
  },
  {
    "revision": "9c81960be9525c6ae4c2",
    "url": "/static/js/3.9acde3df.chunk.js"
  },
  {
    "revision": "2728ffaf0102dd325848",
    "url": "/static/js/30.4cc5dd7a.chunk.js"
  },
  {
    "revision": "4dde715b989e4a10d005",
    "url": "/static/js/31.8f5228df.chunk.js"
  },
  {
    "revision": "827fd5c0a5c988632370",
    "url": "/static/js/32.80519791.chunk.js"
  },
  {
    "revision": "a46f0601caa45bb5e5ea",
    "url": "/static/js/33.e010fc6f.chunk.js"
  },
  {
    "revision": "5f0c65fa52d525554f72",
    "url": "/static/js/34.d57a4c38.chunk.js"
  },
  {
    "revision": "f6300a47bdc35519a4ad",
    "url": "/static/js/35.541434ad.chunk.js"
  },
  {
    "revision": "8302e9fab8e646206cef",
    "url": "/static/js/36.3c28f383.chunk.js"
  },
  {
    "revision": "52ac7ea69e086ca01bab",
    "url": "/static/js/37.b8f4679b.chunk.js"
  },
  {
    "revision": "4986f8eb7c5a457c6b0f",
    "url": "/static/js/38.8123fce3.chunk.js"
  },
  {
    "revision": "f70db7efe1165d64578a",
    "url": "/static/js/39.367d8a8d.chunk.js"
  },
  {
    "revision": "8c6402ed5273e282f173",
    "url": "/static/js/4.1453a532.chunk.js"
  },
  {
    "revision": "b31c0e564076a05eaaf6",
    "url": "/static/js/40.dcd4d1e4.chunk.js"
  },
  {
    "revision": "104e53a77914c5fe349d",
    "url": "/static/js/41.6de05704.chunk.js"
  },
  {
    "revision": "19bc6e4fde36a87ad35b",
    "url": "/static/js/42.eaa2dd4f.chunk.js"
  },
  {
    "revision": "cb7fd962d0c5bd5e9ffa",
    "url": "/static/js/43.1f091590.chunk.js"
  },
  {
    "revision": "1436ceadc0ec9b9eb67b",
    "url": "/static/js/44.6d9cfef2.chunk.js"
  },
  {
    "revision": "42c1dc7fe617b8226a9f",
    "url": "/static/js/45.eb21a869.chunk.js"
  },
  {
    "revision": "a141c52b76e3a16e0ca1",
    "url": "/static/js/46.f01e19fa.chunk.js"
  },
  {
    "revision": "8a6492ef25c248615324",
    "url": "/static/js/47.40df8f9c.chunk.js"
  },
  {
    "revision": "dfe242a43180debec03e",
    "url": "/static/js/48.fff63032.chunk.js"
  },
  {
    "revision": "74dec2210cc4a7a245ee",
    "url": "/static/js/49.2770c876.chunk.js"
  },
  {
    "revision": "dcc9f8c9f2160f08131d",
    "url": "/static/js/5.e24702dc.chunk.js"
  },
  {
    "revision": "d478f44754f7510fbf45",
    "url": "/static/js/50.d0401813.chunk.js"
  },
  {
    "revision": "40710646cc11685bc3d6",
    "url": "/static/js/51.15eac578.chunk.js"
  },
  {
    "revision": "113d723923c8fb255881",
    "url": "/static/js/52.a3f34c8b.chunk.js"
  },
  {
    "revision": "2e6a105c0f5f98d894ab",
    "url": "/static/js/53.8dfca399.chunk.js"
  },
  {
    "revision": "f1e6c48c8ac8ab0a5d2c",
    "url": "/static/js/54.340f8ac4.chunk.js"
  },
  {
    "revision": "ea53531513ec18eb9eca",
    "url": "/static/js/55.ac61ede4.chunk.js"
  },
  {
    "revision": "1a47142bee067150e5a1",
    "url": "/static/js/56.0d044213.chunk.js"
  },
  {
    "revision": "82e2f426e6ee98c91c91",
    "url": "/static/js/57.01a75606.chunk.js"
  },
  {
    "revision": "14e147d670296166c318",
    "url": "/static/js/58.c4693689.chunk.js"
  },
  {
    "revision": "49bb1c6993d1407fac3e",
    "url": "/static/js/59.0bdd6110.chunk.js"
  },
  {
    "revision": "5f3ec1954793723a89a2",
    "url": "/static/js/6.30e3a6cc.chunk.js"
  },
  {
    "revision": "4b851c44b6c729e7ef2c",
    "url": "/static/js/60.a64f9602.chunk.js"
  },
  {
    "revision": "114f8c538ddb412c542f",
    "url": "/static/js/61.2d9a8fd7.chunk.js"
  },
  {
    "revision": "274943fb9b88031a18ae",
    "url": "/static/js/62.53de37b8.chunk.js"
  },
  {
    "revision": "9bf5d0a11b13fd9744b6",
    "url": "/static/js/63.2a69883c.chunk.js"
  },
  {
    "revision": "e6d0f2db537f4ae692ce",
    "url": "/static/js/64.05be6f37.chunk.js"
  },
  {
    "revision": "6a8660c61aafc4f78f5d",
    "url": "/static/js/65.d6308583.chunk.js"
  },
  {
    "revision": "3f3490d3071f60fdd26d",
    "url": "/static/js/66.b4fc989e.chunk.js"
  },
  {
    "revision": "27fc3a8b7f0948f6dff0",
    "url": "/static/js/67.5f4e12f1.chunk.js"
  },
  {
    "revision": "ff139219c48f03876fc2",
    "url": "/static/js/68.38fe2b5e.chunk.js"
  },
  {
    "revision": "a3c8988a69aa32815dd6",
    "url": "/static/js/69.a90041a5.chunk.js"
  },
  {
    "revision": "950ad2e9e3d4dba5f1e7",
    "url": "/static/js/7.da97027e.chunk.js"
  },
  {
    "revision": "def243a27ef86ef4e6d6",
    "url": "/static/js/70.1a731523.chunk.js"
  },
  {
    "revision": "08e3c7aca054210a478b",
    "url": "/static/js/71.f7dffb51.chunk.js"
  },
  {
    "revision": "dc01cb78a2e722f981cc",
    "url": "/static/js/72.7f142c5d.chunk.js"
  },
  {
    "revision": "de4aea957ea30997198b",
    "url": "/static/js/73.34e13495.chunk.js"
  },
  {
    "revision": "8e8c007b4564d197e537",
    "url": "/static/js/74.788d72b9.chunk.js"
  },
  {
    "revision": "91a90daca4d37da95ba7",
    "url": "/static/js/75.25a588f0.chunk.js"
  },
  {
    "revision": "448a02e0b6329bcd67e8",
    "url": "/static/js/76.7f18856b.chunk.js"
  },
  {
    "revision": "534af35fa43b9908eaa0",
    "url": "/static/js/77.9efa9322.chunk.js"
  },
  {
    "revision": "fe3862883f4f3de7327a",
    "url": "/static/js/78.05858d3f.chunk.js"
  },
  {
    "revision": "c975c38478a5154fbd77",
    "url": "/static/js/79.7f1ade06.chunk.js"
  },
  {
    "revision": "007aefe7b9cce61f8fc2",
    "url": "/static/js/8.ea1302af.chunk.js"
  },
  {
    "revision": "cd3642f18e023b990491",
    "url": "/static/js/80.c4f3d2f9.chunk.js"
  },
  {
    "revision": "79752556c8d8fdaea21f",
    "url": "/static/js/81.977f9dfc.chunk.js"
  },
  {
    "revision": "2ee3ef3d389377cd04a2",
    "url": "/static/js/82.02166ab6.chunk.js"
  },
  {
    "revision": "1a5de9202b1a989184f7",
    "url": "/static/js/9.22ed3d92.chunk.js"
  },
  {
    "revision": "5905b3d2ea32786aed4e",
    "url": "/static/js/main.48c24cb8.chunk.js"
  },
  {
    "revision": "ba3d29fe290b34a5731d",
    "url": "/static/js/runtime-main.84259873.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);