self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b51650a76899fef8ae9a2c112b2ae52a",
    "url": "/index.html"
  },
  {
    "revision": "20a9b4813bfd5a06c32b",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "9e12978d63ac3acee49c",
    "url": "/static/css/12.2e947bf2.chunk.css"
  },
  {
    "revision": "aedf97ab7b2c17bc69c2",
    "url": "/static/css/13.b459137f.chunk.css"
  },
  {
    "revision": "e2158346798c18c369a0",
    "url": "/static/css/14.834d426e.chunk.css"
  },
  {
    "revision": "e898cf174f97259ef8d5",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "20a9b4813bfd5a06c32b",
    "url": "/static/js/0.45d9e41f.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.45d9e41f.chunk.js.LICENSE.txt"
  },
  {
    "revision": "4322ce9745a250231bdf",
    "url": "/static/js/1.9e88e3a3.chunk.js"
  },
  {
    "revision": "9e12978d63ac3acee49c",
    "url": "/static/js/12.bd8dd105.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/12.bd8dd105.chunk.js.LICENSE.txt"
  },
  {
    "revision": "aedf97ab7b2c17bc69c2",
    "url": "/static/js/13.d17460c8.chunk.js"
  },
  {
    "revision": "e2158346798c18c369a0",
    "url": "/static/js/14.e36a6871.chunk.js"
  },
  {
    "revision": "11ccde32d1de3ada62a1",
    "url": "/static/js/15.3c447284.chunk.js"
  },
  {
    "revision": "17d1665fecbc5254b402",
    "url": "/static/js/16.788cedd2.chunk.js"
  },
  {
    "revision": "aa0f83f6df2957f63dc6",
    "url": "/static/js/17.91e185f5.chunk.js"
  },
  {
    "revision": "920ffb0b67d4dd3cebe2",
    "url": "/static/js/18.b0b1b729.chunk.js"
  },
  {
    "revision": "700ded23b307b22b8350",
    "url": "/static/js/19.1c7d9cac.chunk.js"
  },
  {
    "revision": "ac51f7ebc264fe957597",
    "url": "/static/js/2.595faf6a.chunk.js"
  },
  {
    "revision": "d1a75b687ba87aef0a58",
    "url": "/static/js/20.1cf6dbb1.chunk.js"
  },
  {
    "revision": "8d54f3ff7a2321ce5031",
    "url": "/static/js/21.86535876.chunk.js"
  },
  {
    "revision": "539a2154d429769971e0",
    "url": "/static/js/22.4d2179a1.chunk.js"
  },
  {
    "revision": "7c8f3e7f91cff4d0412a",
    "url": "/static/js/23.393a0dcf.chunk.js"
  },
  {
    "revision": "2420123ee7a3865a4e9a",
    "url": "/static/js/24.616053bc.chunk.js"
  },
  {
    "revision": "2aad7ffcb9edda61bc44",
    "url": "/static/js/25.db6ccdde.chunk.js"
  },
  {
    "revision": "ef2b7edffa8c56bae200",
    "url": "/static/js/26.ef349e73.chunk.js"
  },
  {
    "revision": "793ee627f7a12f4962bc",
    "url": "/static/js/27.d7de0711.chunk.js"
  },
  {
    "revision": "90e84ca8c0175aa9c7d8",
    "url": "/static/js/28.45490318.chunk.js"
  },
  {
    "revision": "54f34ba5cc4d257b6c15",
    "url": "/static/js/29.fb634885.chunk.js"
  },
  {
    "revision": "5a3363665cd8651fa991",
    "url": "/static/js/3.17ca33b3.chunk.js"
  },
  {
    "revision": "7f0e764286557e4a6b29",
    "url": "/static/js/30.96a82fcf.chunk.js"
  },
  {
    "revision": "2d49c7fc2ac6ca2c7486",
    "url": "/static/js/31.e0e49904.chunk.js"
  },
  {
    "revision": "77fbdf21333cc5bf8295",
    "url": "/static/js/32.ab394942.chunk.js"
  },
  {
    "revision": "727c8110bedb110ca6a1",
    "url": "/static/js/33.f8bc4e5f.chunk.js"
  },
  {
    "revision": "9d7d44538976e7211d66",
    "url": "/static/js/34.a392fe21.chunk.js"
  },
  {
    "revision": "45f2d471f2b83672335f",
    "url": "/static/js/35.4d5668c6.chunk.js"
  },
  {
    "revision": "31912ac564ef9b724cdd",
    "url": "/static/js/36.88817eba.chunk.js"
  },
  {
    "revision": "af8f2018db2533a2b617",
    "url": "/static/js/37.cca755cd.chunk.js"
  },
  {
    "revision": "7aa3abf76e30171e21c1",
    "url": "/static/js/38.da02ee18.chunk.js"
  },
  {
    "revision": "abeeb714bf760d6aa95a",
    "url": "/static/js/39.9787faa7.chunk.js"
  },
  {
    "revision": "9fc2d6fb92c55f313c70",
    "url": "/static/js/4.badeda7f.chunk.js"
  },
  {
    "revision": "d8924b93da634bbfb517",
    "url": "/static/js/40.3a349193.chunk.js"
  },
  {
    "revision": "2d10564f982cf213fa5c",
    "url": "/static/js/41.0ea3f5c6.chunk.js"
  },
  {
    "revision": "03850216f4a72924cc64",
    "url": "/static/js/42.7b835fa6.chunk.js"
  },
  {
    "revision": "81581857814c08885ca2",
    "url": "/static/js/43.5c4282d4.chunk.js"
  },
  {
    "revision": "7e875b8cf63a7855410e",
    "url": "/static/js/44.5e92cb08.chunk.js"
  },
  {
    "revision": "59919e4ae3a764413cf7",
    "url": "/static/js/45.39b0597e.chunk.js"
  },
  {
    "revision": "e4b15a5073d89d5b770c",
    "url": "/static/js/46.c11bd32c.chunk.js"
  },
  {
    "revision": "79ab3ebb9000a035cc35",
    "url": "/static/js/47.46ba89b7.chunk.js"
  },
  {
    "revision": "1eabc31d092cd0f20a2a",
    "url": "/static/js/48.7cdb7096.chunk.js"
  },
  {
    "revision": "baaf89ffcf9b109613fb",
    "url": "/static/js/49.018633cb.chunk.js"
  },
  {
    "revision": "654d1d94ef8afe480c0a",
    "url": "/static/js/5.249b4de6.chunk.js"
  },
  {
    "revision": "12bbbfaef30643abaa92",
    "url": "/static/js/50.217eed43.chunk.js"
  },
  {
    "revision": "0d984a3e1aedf06ecfd1",
    "url": "/static/js/51.1672a977.chunk.js"
  },
  {
    "revision": "b38b7b03c8c4ada68a6f",
    "url": "/static/js/52.aac38807.chunk.js"
  },
  {
    "revision": "8c89b775858cbf96eb54",
    "url": "/static/js/53.94dbcaaf.chunk.js"
  },
  {
    "revision": "369eded71e08226095fb",
    "url": "/static/js/54.88bf0181.chunk.js"
  },
  {
    "revision": "0297e8a7723fe6a5db7c",
    "url": "/static/js/55.fadd6ada.chunk.js"
  },
  {
    "revision": "e36ada1ac4453a955fa7",
    "url": "/static/js/56.39d4d80a.chunk.js"
  },
  {
    "revision": "fafefe3865ab94016f7a",
    "url": "/static/js/57.e1000863.chunk.js"
  },
  {
    "revision": "b1af8808931a34a99761",
    "url": "/static/js/58.7018d2bd.chunk.js"
  },
  {
    "revision": "ac01dfb047d58a70d8a9",
    "url": "/static/js/59.adeebcec.chunk.js"
  },
  {
    "revision": "ad15cdcf9b121746b250",
    "url": "/static/js/6.0b777c8a.chunk.js"
  },
  {
    "revision": "ea1917384170cca83359",
    "url": "/static/js/60.11537ca1.chunk.js"
  },
  {
    "revision": "5ed3416400a6ae6e55bb",
    "url": "/static/js/61.fba26a6e.chunk.js"
  },
  {
    "revision": "a4cb1c3ab8000cfbffa7",
    "url": "/static/js/62.1d9921b6.chunk.js"
  },
  {
    "revision": "7cab24036fd86158a3d3",
    "url": "/static/js/63.e3916cb8.chunk.js"
  },
  {
    "revision": "b6b547fece9e4aff1462",
    "url": "/static/js/64.b465a7d4.chunk.js"
  },
  {
    "revision": "c86eaa3b002f9838b886",
    "url": "/static/js/65.3821ce80.chunk.js"
  },
  {
    "revision": "4ad48ecb90a38cff465d",
    "url": "/static/js/66.92ee86f8.chunk.js"
  },
  {
    "revision": "b7b91ace5813a9cca433",
    "url": "/static/js/67.c26c30b6.chunk.js"
  },
  {
    "revision": "e011278d8f2fd7d91339",
    "url": "/static/js/68.8dee0375.chunk.js"
  },
  {
    "revision": "c5a2dc9de248ec97ef45",
    "url": "/static/js/69.3819c36a.chunk.js"
  },
  {
    "revision": "18f10e54f2cbf39f8629",
    "url": "/static/js/7.8a0ca832.chunk.js"
  },
  {
    "revision": "622333273557dddee514",
    "url": "/static/js/70.22af957c.chunk.js"
  },
  {
    "revision": "45e2919226b7c6b6f562",
    "url": "/static/js/71.1722d795.chunk.js"
  },
  {
    "revision": "0a29fddcfccb29055ea0",
    "url": "/static/js/72.316b64e3.chunk.js"
  },
  {
    "revision": "492b2ce42f3194f71b12",
    "url": "/static/js/73.76b4528a.chunk.js"
  },
  {
    "revision": "c0cc0f727e7fbab846ea",
    "url": "/static/js/74.7b78ca4e.chunk.js"
  },
  {
    "revision": "bd9ce277968ca4231b69",
    "url": "/static/js/75.ac217ea0.chunk.js"
  },
  {
    "revision": "32e62228c2a0c5bf3002",
    "url": "/static/js/76.64c4bf6c.chunk.js"
  },
  {
    "revision": "a284bf846256a1257a7d",
    "url": "/static/js/77.b1e41719.chunk.js"
  },
  {
    "revision": "d35fc5aa24d18bdb51f2",
    "url": "/static/js/78.435a15ea.chunk.js"
  },
  {
    "revision": "901ee8e76b9724bc3549",
    "url": "/static/js/79.317ef834.chunk.js"
  },
  {
    "revision": "3a05b81827f7bebf23c3",
    "url": "/static/js/8.fb358ce4.chunk.js"
  },
  {
    "revision": "bb5348fe8d3ca5d9caa0",
    "url": "/static/js/80.b10dafab.chunk.js"
  },
  {
    "revision": "85530c4093cd943f21ec",
    "url": "/static/js/81.e609d84b.chunk.js"
  },
  {
    "revision": "7649b5544f05d9eee9ac",
    "url": "/static/js/82.b5d6cc0a.chunk.js"
  },
  {
    "revision": "bdb5e94a4d9778834e84",
    "url": "/static/js/9.5d222527.chunk.js"
  },
  {
    "revision": "e898cf174f97259ef8d5",
    "url": "/static/js/main.6534cc8f.chunk.js"
  },
  {
    "revision": "45ff0bc5e61ff414d9f7",
    "url": "/static/js/runtime-main.dc5f8faf.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);