self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b36fa28be30925175b00e89022903e3b",
    "url": "/index.html"
  },
  {
    "revision": "6656ffcb83a9f7147a26",
    "url": "/static/css/0.3e68da18.chunk.css"
  },
  {
    "revision": "c0015e2e09cdfb9778c2",
    "url": "/static/css/13.2e947bf2.chunk.css"
  },
  {
    "revision": "ea37734da702eb6aa423",
    "url": "/static/css/14.e9327155.chunk.css"
  },
  {
    "revision": "f82e30e0275974e51831",
    "url": "/static/css/15.ac09eb94.chunk.css"
  },
  {
    "revision": "802b748bf16758606b78",
    "url": "/static/css/main.dfb41827.chunk.css"
  },
  {
    "revision": "6656ffcb83a9f7147a26",
    "url": "/static/js/0.fc35e82b.chunk.js"
  },
  {
    "revision": "783f14fa45b10e088e68f98251448010",
    "url": "/static/js/0.fc35e82b.chunk.js.LICENSE.txt"
  },
  {
    "revision": "66fc30ab327e8e9b0e3d",
    "url": "/static/js/1.6ef87eeb.chunk.js"
  },
  {
    "revision": "3403871a3f80a8a1b6a4",
    "url": "/static/js/10.2fcf2145.chunk.js"
  },
  {
    "revision": "c0015e2e09cdfb9778c2",
    "url": "/static/js/13.1cd97d6e.chunk.js"
  },
  {
    "revision": "f2fce78a0a0a19c2649c6b24e52364fd",
    "url": "/static/js/13.1cd97d6e.chunk.js.LICENSE.txt"
  },
  {
    "revision": "ea37734da702eb6aa423",
    "url": "/static/js/14.46576ac3.chunk.js"
  },
  {
    "revision": "f82e30e0275974e51831",
    "url": "/static/js/15.fa456d17.chunk.js"
  },
  {
    "revision": "f96e2c810c9d7fe072cc",
    "url": "/static/js/16.2463bb16.chunk.js"
  },
  {
    "revision": "ef9e86caa12ea28edff2",
    "url": "/static/js/17.e0fc1ca0.chunk.js"
  },
  {
    "revision": "872870f0767860b0d29c",
    "url": "/static/js/18.28fd6497.chunk.js"
  },
  {
    "revision": "5ad0352b23dc286f8958",
    "url": "/static/js/19.07ce31cc.chunk.js"
  },
  {
    "revision": "753238288a4ef1bc1abd",
    "url": "/static/js/2.eac88ae0.chunk.js"
  },
  {
    "revision": "2197c1b1f0ab040626d7",
    "url": "/static/js/20.9997ad98.chunk.js"
  },
  {
    "revision": "0af7ded0915932149259",
    "url": "/static/js/21.b8ad82cd.chunk.js"
  },
  {
    "revision": "c53423fe35f2a1a298ae",
    "url": "/static/js/22.56215276.chunk.js"
  },
  {
    "revision": "99c21f36f0b92cec489e",
    "url": "/static/js/23.7ea00460.chunk.js"
  },
  {
    "revision": "bd5d37fc0da3c25f14b7",
    "url": "/static/js/24.fde72bf4.chunk.js"
  },
  {
    "revision": "4cc2deafe62b893db95e",
    "url": "/static/js/25.c2552a12.chunk.js"
  },
  {
    "revision": "d214cf21bbe4d6cc19c4",
    "url": "/static/js/26.1ca514a4.chunk.js"
  },
  {
    "revision": "8c489c96b703eca2b6af",
    "url": "/static/js/27.54914334.chunk.js"
  },
  {
    "revision": "11525abcd169bb97faec",
    "url": "/static/js/28.463c0850.chunk.js"
  },
  {
    "revision": "1939e70cc97f61f526ea",
    "url": "/static/js/29.1a6d9820.chunk.js"
  },
  {
    "revision": "5f4bb469a89741af3638",
    "url": "/static/js/3.aaf652b1.chunk.js"
  },
  {
    "revision": "ba681fbf409a77330c0f",
    "url": "/static/js/30.85140c55.chunk.js"
  },
  {
    "revision": "0f8a44489496c8834d45",
    "url": "/static/js/31.d35b47ae.chunk.js"
  },
  {
    "revision": "ddf8fa3dcef36e6f57af",
    "url": "/static/js/32.1880b926.chunk.js"
  },
  {
    "revision": "8c2e8ca8db4aa79b8c31",
    "url": "/static/js/33.2bb43edf.chunk.js"
  },
  {
    "revision": "5282d218da303dff1ff0",
    "url": "/static/js/34.2d993f26.chunk.js"
  },
  {
    "revision": "0ef63a4f8a99ff715c94",
    "url": "/static/js/35.71ff12a6.chunk.js"
  },
  {
    "revision": "75e57da02c37c02f77ec",
    "url": "/static/js/36.a7a54923.chunk.js"
  },
  {
    "revision": "ed74043e6bbae10b7898",
    "url": "/static/js/37.24c8e4ab.chunk.js"
  },
  {
    "revision": "ae4747c7f9083d634903",
    "url": "/static/js/38.dd28b9e5.chunk.js"
  },
  {
    "revision": "17bb6bc42a573cdf1a33",
    "url": "/static/js/39.b82b7b09.chunk.js"
  },
  {
    "revision": "5a2b2acb292fe5208fd9",
    "url": "/static/js/4.e509f4e0.chunk.js"
  },
  {
    "revision": "9b2bc4ed378c1dbc8e6e",
    "url": "/static/js/40.be6d3da3.chunk.js"
  },
  {
    "revision": "4e2f7d580b5d84f7847c",
    "url": "/static/js/41.4967b104.chunk.js"
  },
  {
    "revision": "3687bb14194d7548ba2c",
    "url": "/static/js/42.f491304e.chunk.js"
  },
  {
    "revision": "cd09b04121922f7186ec",
    "url": "/static/js/43.0f6eb2c5.chunk.js"
  },
  {
    "revision": "37f4f5558e7b5f837027",
    "url": "/static/js/44.bd5a2364.chunk.js"
  },
  {
    "revision": "90e97ae9a46b8bd00939",
    "url": "/static/js/45.08a0e7a5.chunk.js"
  },
  {
    "revision": "5492875d802e5e05fef4",
    "url": "/static/js/46.ed07c192.chunk.js"
  },
  {
    "revision": "77b246a31778df06726c",
    "url": "/static/js/47.50703764.chunk.js"
  },
  {
    "revision": "7b75dede80eca4af4f0d",
    "url": "/static/js/48.b0933049.chunk.js"
  },
  {
    "revision": "1e32a84947b87ceeb27a",
    "url": "/static/js/49.f71fc117.chunk.js"
  },
  {
    "revision": "ef0e7f986f422d390ab7",
    "url": "/static/js/5.0d418e3e.chunk.js"
  },
  {
    "revision": "7c1d44727bf61185270e",
    "url": "/static/js/50.a532adef.chunk.js"
  },
  {
    "revision": "d5c92091caab561450dc",
    "url": "/static/js/51.ec8c6d92.chunk.js"
  },
  {
    "revision": "b1a85821a3b18270af81",
    "url": "/static/js/52.3a0a4177.chunk.js"
  },
  {
    "revision": "bd672991d27fbe396b33",
    "url": "/static/js/53.05ec2818.chunk.js"
  },
  {
    "revision": "b2800a5db2366db9a4a5",
    "url": "/static/js/54.ee91b330.chunk.js"
  },
  {
    "revision": "a69404c5d75148ba1d0e",
    "url": "/static/js/55.dfbac1e5.chunk.js"
  },
  {
    "revision": "4d938daa29079162fa66",
    "url": "/static/js/56.097dc397.chunk.js"
  },
  {
    "revision": "d7d0fdde152e5cbe1b6d",
    "url": "/static/js/57.616a35ec.chunk.js"
  },
  {
    "revision": "011516bbfe5cc06ef5f2",
    "url": "/static/js/58.7ac58272.chunk.js"
  },
  {
    "revision": "72b8984a0a5cf7de9618",
    "url": "/static/js/59.a4e2233a.chunk.js"
  },
  {
    "revision": "02dc4302a77237c87750",
    "url": "/static/js/6.b882b66a.chunk.js"
  },
  {
    "revision": "ea943e334e41485409bc",
    "url": "/static/js/60.0f705103.chunk.js"
  },
  {
    "revision": "db33e1b96d674ac2255c",
    "url": "/static/js/61.5df6b781.chunk.js"
  },
  {
    "revision": "d164408eedb6b9f9f6fd",
    "url": "/static/js/62.fd70d6af.chunk.js"
  },
  {
    "revision": "70d731d0dde9eecddce2",
    "url": "/static/js/63.752ed5be.chunk.js"
  },
  {
    "revision": "80c132a5dfffb94dbae3",
    "url": "/static/js/64.8b54a75b.chunk.js"
  },
  {
    "revision": "f59c66202662ceaf071f",
    "url": "/static/js/65.85ae9fd4.chunk.js"
  },
  {
    "revision": "f700fabc228c3024454b",
    "url": "/static/js/66.78321d55.chunk.js"
  },
  {
    "revision": "8722cac35694f813bdd8",
    "url": "/static/js/67.3cf9f67a.chunk.js"
  },
  {
    "revision": "3447d193db89f7bd69f7",
    "url": "/static/js/68.58e1c3d6.chunk.js"
  },
  {
    "revision": "2b27870c4933e39a76bc",
    "url": "/static/js/69.31e8f904.chunk.js"
  },
  {
    "revision": "ab419e79a74edd9700f8",
    "url": "/static/js/7.b1e481f2.chunk.js"
  },
  {
    "revision": "38413208fcf56cee566f",
    "url": "/static/js/70.93026fda.chunk.js"
  },
  {
    "revision": "f0dc26e3d0d5aff037b5",
    "url": "/static/js/71.8bd5ad02.chunk.js"
  },
  {
    "revision": "d777c8b12354dee46b0d",
    "url": "/static/js/72.01cd3746.chunk.js"
  },
  {
    "revision": "e2599d0e6a20850e0d12",
    "url": "/static/js/73.0c1a5f3f.chunk.js"
  },
  {
    "revision": "d60aacdb1a65d37a4194",
    "url": "/static/js/74.3252bf83.chunk.js"
  },
  {
    "revision": "266e028c45e866c77f63",
    "url": "/static/js/75.7a283ae7.chunk.js"
  },
  {
    "revision": "880f34ebc02872ad0b1f",
    "url": "/static/js/76.87374e8b.chunk.js"
  },
  {
    "revision": "3c281ee65fd9d419d34e",
    "url": "/static/js/77.96dcf39b.chunk.js"
  },
  {
    "revision": "3bf644083c532229db9c",
    "url": "/static/js/78.b515b437.chunk.js"
  },
  {
    "revision": "78524ac706bb9f9caf3c",
    "url": "/static/js/79.577d141e.chunk.js"
  },
  {
    "revision": "82cff9554970606bf0c9",
    "url": "/static/js/8.ba8c326a.chunk.js"
  },
  {
    "revision": "f3af23590b1cdee42a80",
    "url": "/static/js/80.24f98a51.chunk.js"
  },
  {
    "revision": "f2f8a8948ae784fb357e",
    "url": "/static/js/81.923779e2.chunk.js"
  },
  {
    "revision": "e246916d42cdafde1362",
    "url": "/static/js/82.76df66d1.chunk.js"
  },
  {
    "revision": "e7c2ffed27ad9baf929c",
    "url": "/static/js/83.981dac6c.chunk.js"
  },
  {
    "revision": "9bbf23f53a15b320f05c",
    "url": "/static/js/84.f7a9a4b6.chunk.js"
  },
  {
    "revision": "a634db2768f1961cfbc3",
    "url": "/static/js/85.1acbc00c.chunk.js"
  },
  {
    "revision": "83f4e34f6f1c71988b11",
    "url": "/static/js/9.4e39e602.chunk.js"
  },
  {
    "revision": "802b748bf16758606b78",
    "url": "/static/js/main.5310c02f.chunk.js"
  },
  {
    "revision": "0b58cfbf757819408995",
    "url": "/static/js/runtime-main.0ed8ae96.js"
  },
  {
    "revision": "35c254f1bc43c56e8cfae5d817be8d5f",
    "url": "/static/media/1.35c254f1.jpg"
  },
  {
    "revision": "e3ecc43c35f3e4d97bf187e8fccd9965",
    "url": "/static/media/2.e3ecc43c.jpg"
  },
  {
    "revision": "ed038830eaa255c8c2d58ed871d54f97",
    "url": "/static/media/3.ed038830.jpg"
  },
  {
    "revision": "98c972f61e9885a0ceeaa243aacfa7d6",
    "url": "/static/media/4.98c972f6.jpg"
  },
  {
    "revision": "3c60e090c7128eb1c57e03cabe091c05",
    "url": "/static/media/404.3c60e090.png"
  },
  {
    "revision": "11911410dca2de148f30954eb2fd5eab",
    "url": "/static/media/arrow_left.11911410.svg"
  },
  {
    "revision": "8ef6a08cdc1154920165680a4edde771",
    "url": "/static/media/arrow_right.8ef6a08c.svg"
  },
  {
    "revision": "035047178ed13101f120c47e1f36b043",
    "url": "/static/media/avatar.03504717.png"
  },
  {
    "revision": "ad04b412ac89dfa2f4fb8734d387cad0",
    "url": "/static/media/faq.ad04b412.jpg"
  },
  {
    "revision": "3d2fa2e544004aef2ea641698b715af6",
    "url": "/static/media/feather.3d2fa2e5.woff"
  },
  {
    "revision": "6a750f0119ba9c8ab8a994a4796599a6",
    "url": "/static/media/feather.6a750f01.ttf"
  },
  {
    "revision": "7975b0a027366be768319ee2f9e1734e",
    "url": "/static/media/feather.7975b0a0.svg"
  },
  {
    "revision": "931c9e74d0b20947054bfe6a5b74a838",
    "url": "/static/media/feather.931c9e74.eot"
  },
  {
    "revision": "b17d26ffb93bddee5e782ca657ae7efd",
    "url": "/static/media/kasino-logo.b17d26ff.png"
  },
  {
    "revision": "e45627865b1429eb3f10a2b6c19541bd",
    "url": "/static/media/parallax-4.e4562786.jpg"
  }
]);